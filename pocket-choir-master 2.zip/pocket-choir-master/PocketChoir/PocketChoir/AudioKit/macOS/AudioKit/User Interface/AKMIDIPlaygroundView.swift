//
//  AKMIDIKeyboardPlaygroundView.swift
//  AudioKit For macOS
//
//  Created by Aurelius Prochazka, revision history on Githbub.
//  Copyright © 2018 AudioKit. All rights reserved.
//

import Foundation
