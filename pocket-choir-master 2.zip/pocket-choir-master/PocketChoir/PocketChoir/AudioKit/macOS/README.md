# AudioKit For macOS Xcode project

This project is used to build the AudioKit and AudioKitUI frameworks. It can also be used directly by dragging the .xcodeproj into your Xcode project and adding the two AudioKit frameworks as embedded binaries (under the "General" tab).

The AudioKit folder here contains code specific to macOS that would not work on the iOS or tVOS platform.  Mostly these are Cocoa based User Interface elements.